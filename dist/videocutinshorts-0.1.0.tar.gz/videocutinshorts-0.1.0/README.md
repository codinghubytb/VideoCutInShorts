# VideoCutInShorts

**VideoCutInShorts** est une bibliothèque Python permettant de découper une vidéo en plusieurs parties égales et d'enregistrer les chemins des fichiers vidéo dans un fichier texte. Cette bibliothèque utilise `moviepy` pour la manipulation des vidéos.

## Installation

Pour installer la bibliothèque, tu peux cloner le projet ou le télécharger et ensuite l'installer en local avec `pip` :

```bash
pip install .
